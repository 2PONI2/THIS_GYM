from .manager import DataBase

db = DataBase()