from sqlalchemy import Column, Integer, String
from .db import Base


class Tasks(Base):

    __tablename__ = 'tasks'

    id = Column(Integer, primary_key=True, index=True,  unique=True)
    description = Column(String)
    minutes = Column(Integer)
    user_id = Column(Integer)

